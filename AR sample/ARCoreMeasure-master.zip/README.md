# ARCoreMeasure
source code of ARCore Measure app.

Google play: https://play.google.com/store/apps/details?id=com.hl3hl3.arcoremeasure

demo video: (Measure the belly of my cat with ARCore) https://youtu.be/-7hDq9rnzjI

# Important
Before you build and run this project, please 

* change the **Fabric ApiKey** in **AndroidManifest.xml**
* change the **apiSecret** in **fabric.properties**


# License
[MIT](http://opensource.org/licenses/MIT)
